// Ojhan Ardalan A3 CISP 401 Fall 2018
// Multiply3Test.java
import java.util.*; //imports the util class
public class Multiply3Test {
	public static void main(String[] args) {
		Multiply3.quiz(); //calls the quiz method in Multiply3
		Multiply3.printQuestionResult(); //calls the printQuestionResult method in Multiply 3
	}
}
